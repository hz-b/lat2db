local object in MAD
local hmonitor, instrument, element in MAD.element

print("object", object)
print(hmonitor:is_instanceOf(instrument)) -- display: true

for _, a in ipairs(hmonitor:get_varkeys(instrument)) do
   print(a)
end

local quadrupole in MAD.element
print(quadrupole)
for _i, in ipairs(3..10) do
   print(ring[i])
end

local mq = quadrupole 'mq' {l = 2.0 }
for key, val in pairs(mq) do
   print(key, val)
end
