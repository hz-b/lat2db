"""Twiss parameters for the Proton Synchrotron

Main use:
     demonstrate the export of mad-ng mtable to
     numpy arrays or pandas dataframes
"""
from pymadng import MAD
from pymadng_utils.dataframe import mad_table_to_dataframe

import matplotlib.pyplot as plt
import datetime
import numpy as np

import logging
import os
from pathlib import Path

logger = logging.getLogger("pymadng.utils")

current_dir = os.path.dirname(os.path.realpath(__file__)) + "/"

t_dir = Path(os.path.abspath(os.path.dirname(__file__)))
t_file = t_dir / "BII_standarduserReference.seq"
mad_path = Path(os.environ["HOME"]) / "bin" / "mad"


with MAD(debug=False) as mad:
    mad["beam"] = mad.beam(particle="'proton'", pc=2.794987)
    mad.MADX.BEAM = mad.beam
    mad.MADX.BRHO = mad.beam.brho
    mad.MADX.load(f"'{t_file}'")

    mad.load("MADX", "ring")
    mad.ring.beam = mad.beam

    # here just as a check to see if possible.
    # is it necessary at that stage
    mad["srv_tbl", "mflw_srv"] = mad.survey(sequence=mad.ring)
    mflw_srv = mad["mflw_srv"]
    srv_tbl = mad_table_to_dataframe(mad["srv_tbl"])
    #
    X0 = np.zeros((1, 6), float)
    X0[0] = 10e-2
    mad["trk_tbl", "trk_mflw", "trk_eidx"] = mad.track(sequence=mad.ring, beam=mad.beam, X0=X0, deltap=0, mapdef=True)
    trk_tbl = mad_table_to_dataframe(mad["trk_tbl"])
    trk_mflw = mad["trk_mflw"]
    trk_eidx = mad["trk_eidx"]
    #
    # # print("mflw", mad["trk_mflw"])
    # # print(dir(mad["trk_mflw"]))
    # trk_mflw = mad["trk_mflw"]
    # t_x = mad["trk_mflw"][0][0]

    # mad["mflw_tbl", "mflw_co"] = mad.cofind(sequence=mad.ring, beam=mad.beam)

    # co_tbl = mad_table_to_dataframe(mad["closed_orbit"])

    now = datetime.datetime.now
    tic = now()
    mad["tws_tbl", "tws_mflw"] = mad.twiss(
        sequence=mad.ring, method=6, nslice=3, chrom=True
    )
    twiss_flw = mad["tws_mflw"]
    tac = now()
    twiss_tbl = mad_table_to_dataframe(mad["tws_tbl"])
    toc = now()

    txt = f"""
    Time estimate (cold): twiss  calculation {(tac-tic).total_seconds():.2f} [s]
                          twiss  table to df {(toc-tac).total_seconds():.2f} [s]
    """
    print(txt)

    fig, axes = plt.subplots(2, 1, sharex=True)
    ax_beta, ax_eta = axes
    ax_beta.plot(twiss_tbl.s, twiss_tbl.beta11, label=r"$\beta_x$")
    ax_beta.plot(twiss_tbl.s, twiss_tbl.beta22, label=r"$\beta_y$")
    ax_beta.set_ylabel(r"$\beta_x$, $\beta_y$ [m]")
    ax_beta.legend()

    ax_eta.set_ylabel(r"$\eta_x$ [m]")
    ax_eta.set_xlabel("s [m]")
    ax_eta.plot(twiss_tbl.s, twiss_tbl.dx, label=r"$\eta_x$")
    ax_eta.legend()
    # return

    plt.show()
