-- [[
-- ]]

function elem_in_list(elem, type_list)
   assert(elem)
    for i, b in ipairs(type_list) do
       if elem == b then
	  return true
       end
    end
    return false
    end

function is_basic_element(elem)
   local kicker, instrument, thick_element, thin_element, specl_element, object in MAD.element
   local vkick, hkick, vkicker, hkicker, sbend, element in MAD.element
   local object in MAD
   local basic_elements = { kicker, instrument, thick_element, thin_element, specl_element,
			    element, object  }
   return elem_in_list(elem, basic_elements)
end

function table_to_json(t)
   local str = ""
   local first = true
   for key, val in pairs(t) do
      if val then
         -- add separator between elements
         if first then  first = false else  str = str .. ", " end
	 local sval
	 if type(val) == "function" then
	    if key == "hkick" or  key == "vkick" or key == "k0" then
	       print(string.format("%-10s not evaluating key %-10s  as on negative list", t.name, key, val))
	    else
	       -- print(string.format("%-10s evaluating     key %-10s     val %-10s", t.name, key, val))
	       sval = val()
	    end
	 else
	    sval = val
	 end
	 str = str .. string.format('%s="%s"', key, sval)
      end
   end
   return str
end

function inheritance(elem)
   -- check that it does not match basic elements
   local parent = elem.parent
   local chk = is_basic_element(parent)
   if not parent or chk  then
      local str = '{ name = "' .. elem.name .. '",  ' .. table_to_json(elem) .. ' }'
      return str
   end
   local str = inheritance(parent)
   local str =  '{ name = "' .. elem.name .. '", parent = ' .. str .. '}'
   return str

   -- local str = inheritance(elem)
   -- local str =  "{ " .. elem.name .. " parent = " .. str .." }"
   -- print(str)
end

function element_to_json(elem)
   local inh = inheritance(elem)
   local inh_m = string.sub(inh, 2, string.len(inh)-1)
   local str = table_to_json(elem)
   return  string.format("{%s, %s}", inh_m, str)
end


function ring_to_json(ring, max_elements)
   local str = "[\n"
   local first = true
   -- why can I not iterate over the sequence of elements in the ring
   for i, index in ipairs(1..#ring) do
      if max_elements and index > max_elements then
	 -- don't forget to close string , thus no premature return
	 break
      end
      -- each entry on separate line, intended
      if first then first = false else str = str .. ",\n\t" end
      local elem = ring[i]
      str = str .. element_to_json(elem)
   end
   str = str .. "\n]"
   return str
end
