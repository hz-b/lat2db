import gtpsa
import thor_scsi.lib as tslib
from thor_scsi.factory import accelerator_from_config

import numpy as np
import matplotlib.pyplot as plt

import copy
import os
import sys
from pathlib import Path

t_dir = Path(os.path.dirname(__file__))
t_file  = t_dir / "BII_NLKmode_3d_start.lat"

acc = accelerator_from_config(t_file)


nlk_elem = acc.find("KDNL1KR", 0)
intp = tslib.NonLinearKickerInterpolation([(10e-3, 10e-3, 700)])
intp.set_scale(1.0)
nlk_elem.set_field_interpolator(intp)
assert(nlk_elem.get_field_interpolator().get_scale() == 1.0)

# inspect the horizontal field interpolation of the non linear kicker
# field ... currently not working
# todo:
#    inspect wrapper
x_vec = np.linspace(-50, 50, num=500) / 1000
B = np.array([intp.field(np.array([x, 0])) for x in x_vec])

fig, ax = plt.subplots(1, 1, sharex=True)
ax.plot(x_vec * 1000, B.real * 1000, label="$B_y$")
ax.plot(x_vec * 1000, B.imag * 1000, label="$B_x$")
ax.set_title("Non linear kicker field")
ax.set_xlabel("x [m]")
ax.set_ylabel(r"$B_{x,y}$ [mT]")
ax.legend()

fig, ax = plt.subplots(1, 1, sharex=True)
ps = gtpsa.ss_vect_double(0e0)
calc_config = tslib.ConfigType()
def f(x):
    ps.set_zero()
    ps.x = x
    nlk_elem.propagate(calc_config, ps)
    return ps.px
px_vec = np.array([f(x) for x in x_vec])
ax.set_title("Non linear: px vs x")
ax.plot(x_vec*1000, px_vec)
ax.set_xlabel("x [mm]")
ax.set_ylabel(r"$p_x$ [?]")



x_vec = np.linspace(-25, 25, num=500) / 1000
ps = gtpsa.ss_vect_double(0e0)
calc_config = tslib.ConfigType()
def f(x):
    ps.set_zero()
    ps.x = x
    idx = nlk_elem.index

    # WARNING: second argument is not the end but the number of steps
    acc.propagate(calc_config, ps, 0,  idx-1)
    x1 = np.array(copy.copy((ps.x, ps.px)))
    acc.propagate(calc_config, ps, idx-1, 1)
    x2 = np.array(copy.copy((ps.x, ps.px)))
    acc.propagate(calc_config, ps, idx, 1)
    x3 = np.array(copy.copy((ps.x, ps.px)))
    acc.propagate(calc_config, ps, idx+1, 1)
    x4 = np.array(copy.copy((ps.x, ps.px)))
    return (x1, x2, x3, x4)

px_vec = np.array([f(x) for x in x_vec])
fig, axes = plt.subplots(4, 1, sharex=True)
ax1, ax2, ax3, ax4 = axes
ax1.set_title("From septum to kicker: px vs x")
ax1.plot(x_vec*1000, px_vec[:, 0, 1] * 1000, label="before kicker")
ax2.plot(x_vec*1000, px_vec[:, 1, 1] * 1000, label="after kicker")
ax3.plot(x_vec*1000, px_vec[:, 2, 1] * 1000, label="well after kicker")
ax4.plot(x_vec*1000, px_vec[:, 3, 1] * 1000, label="well after kicker")
ax3.set_xlabel("x [mm]")
ax1.set_ylabel(r"$p_x 1$ [?]")
ax2.set_ylabel(r"$p_x 2$ [?]")
ax3.set_ylabel(r"$p_x 3$ [?]")
ax3.set_ylabel(r"$p_x 4$ [?]")
ax.legend()

fig, ax = plt.subplots(1, 1, sharex=True)
ax.set_title("From septum to kicker: px vs x")
ax.plot(x_vec*1000, px_vec[:, 0, 1] * 1000, label="before kicker")
ax.plot(x_vec*1000, px_vec[:, 1, 1] * 1000, label="kicker")
ax.plot(x_vec*1000, px_vec[:, 2, 1] * 1000, label="after kicker")
ax.plot(x_vec*1000, px_vec[:, 3, 1] * 1000, label="well after kicker")
ax.set_xlabel("x [mm]")
ax.set_ylabel(r"$p_x$ [mrad ?]")
ax.legend()


fig, ax = plt.subplots(1, 1, sharex=True)
ax.set_title("From septum to kicker: x at pos vs x at septum")
ax.plot(x_vec*1000, px_vec[:, 0, 0] * 1000, label="before kicker")
ax.plot(x_vec*1000, px_vec[:, 1, 0] * 1000, label="kicker")
ax.plot(x_vec*1000, px_vec[:, 2, 0] * 1000, label="after kicker")
ax.plot(x_vec*1000, px_vec[:, 3, 0] * 1000, label="well after kicker")
ax.set_xlabel("x [mm]")
ax.set_ylabel(r"x @ pos [mm]")
ax.legend()
