-- -*- lua -*-
--[=[
Using mad-ng to export the lattice to thor scsi

A preparation to export it as json.


   Todo:
      check how to insert
   - integration steps
   - information on cavity voltage and harmonic numbers
   - export using io module
]=]

module("export_for_thor_scsi", package.seeall)
local pi in MAD.constant

local rad2deg = 180e0/pi
local names_seen = {}
local N_steerer = 1
local N_bend = 10
local N_sextupole = 2
local N_quadrupole = 4



-- This calls for a proper meta table (class) now
local function mangle_nam(nam)
   --[=[ clear names from unwanted strings, append indices for repeated names

      thor scsi current parser does not accept $ character.
      Furthermore all device names must be unique.

   ]=]--

   local cleared = string.gsub(nam, "($)", "sign_")
   if names_seen[cleared] then
      names_seen[cleared] = names_seen[cleared] + 1
      cleared = cleared .. "_" .. string.format("%d",names_seen[cleared])
   else
      names_seen[cleared] = 1
   end
   return cleared
end

local function fmt_nam(nam)
   -- format name left bound within a forseen withspace range
   return string.format("%-18s", nam)
end


local function fmt_extra_info(elm)
   -- format extra information on device: id and name
   return string.format("% 4d %8.3f ", elm.eidx, elm.s)
end


local function add_extra_info(dsc, elm)
   -- add extra info as a comment after the element description
   return string.format("%-99s # %s", dsc, fmt_extra_info(elm))
end


local function export_marker(mrkr, unused)
   -- export a marker or beam position monitor --
   local kind = "unknown"
   if mrkr.kind == "marker" then
      kind = "Marker"
   elseif mrkr.kind == "monitor" then
      kind = "BPM"
   else
      assert(0)
   end
   assert(mrkr.l == 0e0)

   local nam = mangle_nam(mrkr.name)
   return nam, string.format("%s : %-18s;", fmt_nam(nam), kind)
end


local function export_drift(drft, unused)
   assert(drft.kind == "drift")
   local nam = mangle_nam(drft.name)
   local r = string.format("%s : %-18s, L = % 9.7f;",
			   fmt_nam(nam), "Drift",  drft.l)
   return nam, r
end


local function export_steerer(steerer, unused)
   local ts_kind = "check_failed"
   if steerer.kind == "hkicker" then
      ts_kind = "HorizontalSteerer"
   elseif steerer.kind == "vkicker" then
	 ts_kind = "VerticalSteerer"
   else
      assert(0)
   end

   local nam = mangle_nam(steerer.name)
   local r = string.format("%s : %-18s, L = % 9.7f, N= %d;",
			   fmt_nam(nam), ts_kind, steerer.l, N_steerer)
   return nam, r
end


local function export_angle_tilt(mpole)
   local r = ""
   local tilt = mpole.tilt * rad2deg
   if tilt ~= 0e0 then
      r = r .. string.format(", tilt = % 8.6f ", tilt)
   end
   return r
end


local function export_multipole(mpole, ompole)
   --[=[
      mpole   : multipole info as distributed by survey
      ompole : multipole info as available from MADX
               input file
   ]=]--
   local ts_kind = "check_failed"
   local K = "nan"
   local N = -1
   if mpole.kind == "sextupole" then
      ts_kind = "Sextupole"
      -- Tracy uses multipole expansion in field
      -- but Mad(x) in potential
      K = ompole.k2 / 2e0
      N = N_sextupole
   elseif mpole.kind == "quadrupole" then
      ts_kind = "Quadrupole"
      K = ompole.k1
      N = N_quadrupole
   else
      assert(0)
   end
   assert(mpole.kind == ompole.kind)

   local nam = mangle_nam(mpole.name)
   local r =  string.format("%s : %-18s, L = % 9.7f, K = % 8.6f, N = %d",
		      fmt_nam(nam), ts_kind, mpole.l, K, N)
   r = r .. export_angle_tilt(mpole)
   r = r ..";"
   return nam, r
end


local function export_sbend(mpole, ompole)
   assert(mpole.kind == ompole.kind)
   assert(mpole.kind == "sbend")

   local nam = mangle_nam(mpole.name)
   local T = mpole.angle * rad2deg
   local r =  string.format("%s : %-18s, L = % 9.7f, T = % 8.6f",
			    fmt_nam(nam), "Bending", mpole.l, T)

   if ompole.e1 ~= 0e0 then
      r = r .. string.format(", T1 = % 8.6f", ompole.e1 * rad2deg)
   end
   if ompole.e2 ~= 0e0 then
      r = r .. string.format(", T2 = % 8.6f", ompole.e2 * rad2deg)
   end
   if ompole.k1 ~= 0e0 then
      r = r .. string.format(", K = % 8.6f", K)
   else
      r = r .. ", K = 0e0"
   end
   if ompole.k2 ~= 0e0 then
      -- sextupole component according to documentation
      -- conversion from potential to field representation
      local b2 = ompole.k2 / 2
      r = r .. string.format(", K2 = % 8.6f", b2)
   end
   r = r .. string.format(", N= %d", N_bend)
   r = r .. export_angle_tilt(mpole)
   r = r ..";"
   return nam, r
end


local function export_cavity(mpole, ompole)
   assert(mpole.kind == ompole.kind)
   assert(mpole.kind == "rfcavity")

   local nam = mangle_nam(mpole.name)
   local r = string.format(
      "%s : %-18s, L = % 9.7f, Frequency = % 18.6f, Voltage = cavity_voltage, HarmonicNumber = harmonic_number;",
      fmt_nam(nam), "Cavity", mpole.l, ompole.freq, mpole.angle, ompole.tilt
   )
   return nam, r
end


-- dispatch to the different elements
local element_export_dispatcher = {}
element_export_dispatcher[ "marker"     ] = export_marker
element_export_dispatcher[ "monitor"    ] = export_marker
element_export_dispatcher[ "drift"      ] = export_drift
element_export_dispatcher[ "hkicker"    ] = export_steerer
element_export_dispatcher[ "vkicker"    ] = export_steerer
-- currently export multipole only supports sextupoles or quadrupoles
-- need to go further
element_export_dispatcher[ "sextupole"  ] = export_multipole
element_export_dispatcher[ "quadrupole" ] = export_multipole
element_export_dispatcher[ "sbend"      ] = export_sbend
element_export_dispatcher[ "rfcavity"   ] = export_cavity


function export_element(elem, oelm)
   --[=[ elem: element of survey
   oelm, the original element (required e.g. for multipoles)
    print(
      string.format("# % 4d %-20s %-20s % 8.3f",
   		    elem.eidx, elem.name, elem.kind, elem.s)
    )
    if oelm then
      print(" oelm", oelm.name)
   - end
      ]=]--
   local func = element_export_dispatcher[elem.kind]
   if not func then
      print("Do not know how to process element of kind", elem.kind)
      assert(0)
   end
   local nam, r = func(elem, oelm, nil)
   return nam, r
end

function export_elements(survey_tbl, elements_tbl)
 --[=[
    survey_tbl: info as returned by survey
    elements_tbl: table as described in MAD:X file

    returns: a table of
       {name, desc}

    name: thor scsi parser requires each name to be unique.
          thus renaming is required where names occur
          more than once
 ]=]--
   local thor_scsi_tbl = {}
   local no_obj = ""
   -- convert all elements
   for i, v in ipairs(1..#survey_tbl) do
      local elm = survey_tbl[i]
      local eidx = elm.eidx
      local oelm = elements_tbl[eidx] or no_obj
      local nam, r  = export_element(elm, oelm)
      -- print("stored entries", nam, r)
      thor_scsi_tbl[i] = {nam, r}
      --   local elem = mtbl[v]
   end
   return thor_scsi_tbl
end


function print_table(thor_scsi_tbl, survey_tbl)
   --[=[

   ]=]--
   for i, v in ipairs(1..#thor_scsi_tbl) do
      local entry = thor_scsi_tbl[i][2]
      local elm = survey_tbl[i]
      print(add_extra_info(entry, elm))
   end
   print("ring : LINE = (")
   for i, v in ipairs(1..#thor_scsi_tbl) do
      local nam =thor_scsi_tbl[i][1]
      print(string.format("\t%-20s,", nam))
   end
   print(");")
end
