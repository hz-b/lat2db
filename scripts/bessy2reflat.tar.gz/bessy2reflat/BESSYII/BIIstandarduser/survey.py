from pymadng import MAD

import numpy as np
import matplotlib.pyplot as plt
import os.path
from pathlib import Path

import numpy as np
import pandas as pd

t_dir = Path(os.path.abspath(os.path.dirname(__file__)))
t_file = t_dir / "BII_standarduserReference.seq"




def main():
    with MAD(debug=False) as mad:
        quoted_filename = f"'{t_file}'"
        print(quoted_filename)
        mad.MADX.load(quoted_filename)

        mad.load("MADX", "ring")
        mad["mtbl", "mflw"] = mad.survey(sequence=mad.ring)

        mtbl = mad["mtbl"]
        return lua_table_to_dataframe(mtbl)


if __name__ == "__main__":
    import pandas as pd

    r = main()
    print(r, type(r))
    df = pd.DataFrame(r)
    print(df)
    print(df.dtypes)
    df = df.infer_objects()
    print(df.dtypes)
    # print(df)
